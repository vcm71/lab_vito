# Archivos de contexto para el proyecto Orion

**Orden canónico de lectura de sesión:**
1. [arnes_orion.md](./arnes_orion.md)
2. [contexto_orion.md](./contexto_orion.md)

Los documentos `ORION_PROJECT_CONTEXT.md`, `ORION_SESSION_CONTEXT.md` y `orion_contexto_paraGPT` se consideran referencia heredada.

---

### Listado de referencia técnica

1. `package.json` – metadatos y scripts de Vite.
   [package.json](./package.json)

2. `index.html` – plantilla HTML principal. Incluye acordeón de Ajustes_vito con 6 módulos (`moduleThresholds`): docenas, columnas, suertesSencillas, sixenas, ceros, seriesSectores. **Arriba del acordeón** está el campo global `set-atrasos-maxwindow-global` para `atrasosMaxWindow`.
   [index.html](./index.html)

3. `main.js` – punto de entrada JS. Inicializa motores. Define `MODULE_INPUTS` con refs a inputs de `limit` y `critical` por módulo. `inputAtrasosMaxWindow` referencia el campo global. `syncSettingsForm` y save handler trabajan con `moduleThresholds` + `atrasosMaxWindow` en raíz.
   [main.js](./main.js)

4. `rouletteTracker.js` – clase central del rastreador de historial de giros.
   [rouletteTracker.js](./rouletteTracker.js)

5. `vite.config.js` – configuración de Vite.
   [vite.config.js](./vite.config.js)

6. `atrasosRenderer.js` – renderiza la pestaña Atrasos. `buildWidgets(getDelayStats, thresholds)` recibe una sola función `getDelayStats` (factory ya resuelta con el `maxWindow` global) y `thresholds` desde `settings.moduleThresholds`. Todas las secciones (suertes, docenas, columnas, seisenas, ceros, series) comparten el mismo `maxWindow` global.
   [atrasosRenderer.js](./atrasosRenderer.js)

7. `rouletteSettingsStore.js` – almacén de configuración con persistencia IndexedDB. Define `DEFAULT_SETTINGS` con `atrasosMaxWindow:100` en raíz y `moduleThresholds` (6 módulos, cada uno con `{ limit:5, critical:9 }` — sin `maxWindow`). Migración inversa desde `moduleThresholds[module].maxWindow` a `atrasosMaxWindow` raíz en `normalizeSettings`.
   [rouletteSettingsStore.js](./rouletteSettingsStore.js)

8. `controlador_de_la_vista_lab.js` – interfaz ultra-compacta y estética premium (estilo ORION) para la pestaña Lab_Con (Teoría de Conjuntos).
   [controlador_de_la_vista_lab.js](./controlador_de_la_vista_lab.js)

9. `labEngine.js` – motor matemático del Laboratorio Analítico. Incluye `SET_TO_MODULE` (mapping de nombre de conjunto a clave de módulo). `_getSetStats` lee `maxWindow` desde `settings.atrasosMaxWindow` (global) en vez del campo plano o `moduleThresholds[moduleKey]`.
   [labEngine.js](./labEngine.js)

---

### Estructura de settings (a partir de jul 22 — globalización de maxWindow)

```js
{
  atrasosMaxWindow: 100,  // ← global, único para todos los módulos
  moduleThresholds: {
    docenas:          { limit: 5, critical: 9 },  // sin maxWindow
    columnas:         { limit: 5, critical: 9 },
    suertesSencillas: { limit: 5, critical: 9 },
    sixenas:          { limit: 5, critical: 9 },
    ceros:            { limit: 5, critical: 9 },
    seriesSectores:   { limit: 5, critical: 9 }
  }
}
```

IDs en HTML:
- Por módulo: `set-atrasos-{modulo}-limit`, `set-atrasos-{modulo}-critical`
- Global: `set-atrasos-maxwindow-global` (arriba del acordeón)
