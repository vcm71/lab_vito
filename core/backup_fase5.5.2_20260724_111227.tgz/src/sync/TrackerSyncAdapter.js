/**
 * TrackerSyncAdapter — Puente de sincronización entre Domain Tracker y Legacy Tracker.
 *
 * Fase5.2.5 — Inversión de Ownership:
 * RouletteTracker (Domain) es la única fuente de verdad para spins.
 * Legacy Tracker es capa de compatibilidad que refleja el estado del Domain.
 *
 * Ownership:
 *   - Spins: Domain Tracker (única fuente de verdad)
 *   - Sesión: Domain Tracker (sessionManager)
 *   - Historial: Domain Tracker (historyManager)
 *   - Settings: Domain Tracker (settingsManager)
 */
import { SpinManager } from '../tracker/SpinManager.js';

export class TrackerSyncAdapter {
  /**
   * @param {import('../../rouletteTracker.js').RouletteTracker} legacyTracker - Tracker legacy (compatibilidad)
   * @param {import('../tracker/RouletteTracker.js').RouletteTracker} domainTracker - DomainTracker (fuente de verdad)
   */
  constructor(legacyTracker, domainTracker) {
    /** @type {import('../../rouletteTracker.js').RouletteTracker} */
    this._legacy = legacyTracker;

    /** @type {import('../tracker/RouletteTracker.js').RouletteTracker} */
    this._domain = domainTracker;

    this._ready = true;
  }

  // ─── Spins CRUD ─────────────────────────────────────────

  /**
   * Agregar un giro.
   * Domain valida y persiste. Legacy se sincroniza para compatibilidad.
   * @param {string|number} number
   * @returns {object|null} El spin creado o null si inválido
   */
  addSpin(number) {
    const spin = this._domain.addSpin(number);
    if (spin) {
      this._domain.incrementSessionSpinCount();
      this._domain.saveSpins();     // persistencia async (fire-and-forget)
      this._syncAllSpins();         // reflejar en Legacy
    }
    return spin;
  }

  /**
   * Eliminar un giro.
   * Domain primero, luego sincroniza Legacy.
   * @param {number} spinId
   * @returns {boolean}
   */
  deleteSpin(spinId) {
    const result = this._domain.deleteSpin(spinId);
    if (result) {
      this._domain.saveSpins();
      this._syncAllSpins();
    }
    return result;
  }

  /**
   * Actualizar el número de un giro.
   * Domain primero, luego sincroniza Legacy.
   * @param {number} spinId
   * @param {string|number} newNumber
   * @returns {boolean}
   */
  updateSpin(spinId, newNumber) {
    const result = this._domain.updateSpin(spinId, newNumber);
    if (result) {
      this._domain.saveSpins();
      this._syncAllSpins();
    }
    return result;
  }

  /**
   * Limpiar sesión sin grabar en historial.
   * Para uso interno (orionRenderer demo, calibración, etc.)
   */
  clearSession() {
    this._domain.clearSpins();
    this._domain.resetSession();
    this._domain.saveSpins();
    this._syncAllSpins();
  }

  /**
   * Limpiar sesión grabando la actual en historial.
   * 1. DomainTracker guarda sesión y limpia sus spins
   * 2. LegacyTracker limpia sus spins (compatibilidad)
   * @returns {Promise<{saved: boolean, spinCount: number}>}
   */
  async clearSessionAndRecord() {
    let result;
    if (this._domain) {
      result = await this._domain.recordAndClearSession();
      await this._domain.saveSpins(); // persistir estado vacío
    }
    if (this._legacy) {
      this._legacy.clearSession();
    }
    return result || { saved: false, spinCount: 0 };
  }

  /**
   * Importar números masivamente.
   * Domain procesa cada uno con normalización, luego persiste
   * y sincroniza Legacy en batch.
   * @param {string[]} numbersArray - Array de strings con números
   * @returns {object} Reporte de importación
   */
  importSpins(numbersArray) {
    const report = { total: numbersArray.length, valid: 0, discarded: 0, details: [] };
    const discardedSet = new Set();

    numbersArray.forEach(val => {
      const clean = SpinManager.normalizeNumber(val);
      const spin = this._domain.addSpin(clean);
      if (spin) {
        report.valid++;
        this._domain.incrementSessionSpinCount();
      } else {
        report.discarded++;
        discardedSet.add(val);
      }
    });

    report.details = Array.from(discardedSet).slice(0, 10);
    this._domain.saveSpins();
    this._syncAllSpins();
    return report;
  }

  /**
   * Forzar sincronización completa Domain → Legacy.
   */
  syncAllSpins() {
    this._syncAllSpins();
  }

  // ─── Privados ───────────────────────────────────────────

  /**
   * Reflejar todos los spins del Domain en el Legacy Tracker.
   * Reemplaza el array de spins y reconstruye caches internos
   * del Legacy (_freq, Chi², delays) para mantener compatibilidad
   * con renderers que acceden a propiedades privadas.
   */
  _syncAllSpins() {
    const domainSpins = this._domain.getSpins();
    const legacy = this._legacy;

    // Reemplazar array de spins del Legacy (mantener compatibilidad)
    legacy.spins.length = 0;
    domainSpins.forEach(s => {
      legacy.spins.push({ ...s });
    });

    // Reconstruir caches internos del Legacy
    legacy._freq = legacy._buildFreq();
    legacy._chiDirty = true;
    legacy._delaysDirty = true;
    legacy._spinRevision += 1;
  }
}
