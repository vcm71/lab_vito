/**
 * Bootstrap — inicialización del proyecto ORION.
 * Crea Tracker, Stores, Renderers y Motores.
 * Retorna { tracker, services, engines } para que el Kernel registre los motores.
 *
 * NO registra motores en EngineRegistry. Solo los construye.
 * NO crea TomadorRenderer (depende de callbacks de UI que pertenecen a main.js).
 *
 * Fase3 — imports normalizados hacia src/engines/
 * Fase4 — crea el nuevo Dominio RouletteTracker en src/tracker/
 */
import { RouletteTracker } from '../../rouletteTracker.js';
import { LabRenderer } from '../../controlador_de_la_vista_lab.js';
import { rouletteSettingsStore } from '../../rouletteSettingsStore.js';
import { tomadorStateStore } from '../../tomadorStateStore.js';

// Motores normalizados (Fase3)
import { WinWinEngine } from '../engines/WinWin/index.js';
import { DAEngine } from '../engines/DA/index.js';
import { LogicEngine } from '../engines/Orion/index.js';
import { Sesgo97Logic } from '../engines/Sesgo97/index.js';
import { ChiAnalysisEngine } from '../engines/Chi/index.js';
import { KellyManager } from '../engines/Kelly/index.js';

// Dominio Roulette Tracker (Fase4)
import {
  RouletteTracker as DomainTracker,
  TrackerState,
  SpinManager,
  SessionManager,
  HistoryManager,
  SettingsManager
} from '../tracker/index.js';

export class Bootstrap {
  /**
   * Inicializar servicios y motores del sistema.
   * @param {import('./ServiceContainer.js').ServiceContainer} container
   * @returns {Promise<{tracker: RouletteTracker, services: object[], engines: {name:string, instance:object}[]}>}
   */
  static async init(container) {
    // ── Tracker ─────────────────────────────────────────────
    const tracker = new RouletteTracker();
    container.register('tracker', tracker);

    // ── Stores ──────────────────────────────────────────────
    container.register('settingsStore', rouletteSettingsStore);
    container.register('tomadorStateStore', tomadorStateStore);

    // ── LabRenderer ─────────────────────────────────────────
    const labRenderer = new LabRenderer('view-lab', tracker);
    labRenderer.init();
    container.register('labRenderer', labRenderer);

    // Vincular actualizaciones del lab al tracker
    if (typeof tracker.on === 'function') {
      tracker.on('update', () => labRenderer.update());
    } else {
      console.warn('[Orion Lab] Event bus no encontrado, aplicando fallback por interceptación.');
    }

    // ── Dominio Roulette Tracker (Fase4) ────────────────────
    const trackerState = new TrackerState();
    const spinManager = new SpinManager(trackerState);
    const sessionManager = new SessionManager(trackerState);
    const historyManager = new HistoryManager(trackerState);
    const settingsManager = new SettingsManager(trackerState);
    const domainTracker = new DomainTracker(
      trackerState,
      spinManager,
      sessionManager,
      historyManager,
      settingsManager
    );

    // Vincular EventBus si está disponible en el container
    const eventBus = container.resolve('eventBus');
    if (eventBus) {
      domainTracker.setEventBus(eventBus);
    }

    container.register('domainTracker', domainTracker);

    // ── Motores ─────────────────────────────────────────────
    // Orden de creación importa: Orion necesita WinWin
    const winWinEngine = new WinWinEngine(domainTracker);
    const daEngine = new DAEngine(domainTracker);
    const orion = new LogicEngine(domainTracker, winWinEngine);
    const sesgo97Engine = new Sesgo97Logic(domainTracker);
    const chiEngine = new ChiAnalysisEngine(domainTracker);
    const kelly = new KellyManager();

    // Registrar en container
    container.register('winWin', winWinEngine);
    container.register('da', daEngine);
    container.register('orion', orion);
    container.register('sesgo97', sesgo97Engine);
    container.register('chi', chiEngine);
    container.register('kelly', kelly);
    container.register('labRenderer', labRenderer);

    // Estructura para auto-registro en EngineRegistry
    const engines = [
      { name: 'winWin',  instance: winWinEngine },
      { name: 'da',      instance: daEngine },
      { name: 'orion',   instance: orion },
      { name: 'sesgo97', instance: sesgo97Engine },
      { name: 'chi',     instance: chiEngine },
      { name: 'kelly',   instance: kelly }
    ];

    return { tracker, services: [], engines };
  }
}
