# 📎 Arnés de contexto para el proyecto Orion

**Regla de sesión:** este es el primer archivo que debe leerse al comenzar una sesión.  
Después de este archivo, leer `contexto_orion.md`.

## 1️⃣ Hacia dónde vamos
- **Objetivo principal:** Reparar *Roulette Tracker Pro* para que sea totalmente funcional en el host local y ofrecer una experiencia de simulación de ruleta premium y visualmente impactante.
- **Metas intermedias:**
  - Configurar el entorno de desarrollo con Vite.
  - Garantizar que la UI cargue sin errores.
  - Validar la lógica de los motores (`LogicEngine`, `WinWinEngine`, `DAEngine`, etc.) y la persistencia de datos.
  - Añadir mejoras de usabilidad y estética premium (tema oscuro, micro‑animaciones, tipografía moderna).
  - **Refactorizar umbrales de alerta:** Se migró de umbrales planos globales a umbrales independientes por módulo (`moduleThresholds` con 6 módulos), pero **`maxWindow` se revirtió a global** (`atrasosMaxWindow` en raíz de settings) — único valor para todos los módulos, situado arriba del acordeón. `limit` y `critical` permanecen por módulo. Persistencia en IndexedDB.
  - Mantener un respaldo previo al trabajo con rotación automática de 3 copias en `backup_orion/`.

## 2️⃣ Dónde estamos
- **Estado actual del proyecto** (a 24 jul 2026):
  - **Fase5.3 completada — Eliminación de externalSpins + Migración Tester:**
    - Parámetro `externalSpins` eliminado de 3 métodos del Domain (`getHitMap`, `getHitRanking`, `recordAndClearSession`).
    - Único call site (`domainTracker.getHitMap(spins)`) migrado a `domainTracker.getHitMap()` sin argumentos.
    - **Tester** migrado: ahora lee `domainTracker.getSpins()` en lugar de `tracker.getSpins()`.
    - Monte Carlo Validator: autocontenido (dependencia Legacy documentada, a migrar en Fase5.4).
    - **externalSpins eliminado completamente del código base.**
    - **Build: 78 módulos, 0 errores.**
  - **Fase5.2.5 completada — Inversión del Ownership de Spins:**
    - `TrackerSyncAdapter.js` invertido: Domain → Legacy en todos los CRUD.
    - RouletteTracker (Domain) es ahora la única fuente de verdad para giros.
    - Legacy Tracker relegado a capa de compatibilidad (refleja estado del Domain).
    - Monkey-patch en `main.js` redirige `tracker.addSpin/deleteSpin/updateSpin/clearSession`
      al adapter sin modificar renderers.
    - Nuevo método `clearSession()` en adapter (sin grabación en historial).
    - `importSpins()` normaliza y procesa a través del Domain.
    - `_syncAllSpins()` invertido: Domain → Legacy, reconstruye caches (_freq, chi, delays).
    - **Build: 78 módulos, 0 errores.**
  - **`Lab_Con` (Laboratorio Analítico) rediseñado y funcional:**
    - Se reemplazaron las clases de Tailwind por estilos nativos, unificando la estética visual con la pestaña premium `ORION`.
    - Se implementó un "Tapete Estocástico" hiper-compacto, mini-barras de progreso de presión y filtros tipo píldora (`btn-outline`).
    - Se agregó una nueva sección de "Top Números Individuales Más Calientes" que destaca los 5 números individuales más probables en tiempo real.
    - Se corrigió un bug grave en `labEngine.js` donde los atrasos de conjuntos daban siempre 0; ahora lee e itera correctamente el historial directo de `RouletteTracker.spins`.
  - **Refactorización de umbrales completada (jul 22):**
    - `moduleThresholds` con 6 módulos: cada uno tiene `limit` y `critical` independientes.
    - `maxWindow` es **global** (`settings.atrasosMaxWindow`) — un solo campo arriba del acordeón, mismo valor para todos los módulos.
    - `rouletteSettingsStore.js`: `normalizeSettings` ya no extrae `maxWindow` por módulo; lo conserva como `atrasosMaxWindow` en raíz. `DEFAULT_MODULE_THRESHOLDS` solo tiene `{ limit, critical }`.
    - `index.html`: Nuevo input global `set-atrasos-maxwindow-global` arriba del acordeón. Se removieron los 6 inputs `-max` de cada sección.
    - `main.js`: `MODULE_INPUTS` ya no tiene `maxWindow`. El save handler guarda `settings.atrasosMaxWindow` desde el input global.
    - `atrasosRenderer.js`: `buildWidgets` acepta una sola `getDelayStats` (no una factory). Todos los módulos comparten el mismo `maxWindow` global.
    - `labEngine.js`: `_getSetStats` lee `settings.atrasosMaxWindow` en vez de `modThresh.maxWindow`.
  - El diseño modular de `Atrasos` funciona correctamente.
  - Compilación Vite y UI sin errores críticos (verificado con `npm run build` — 78 módulos, ~600ms).
  - Backups periódicos guardados en `backup_orion/` (respaldo adicional en rama git `backup-antes-global-maxwindow`).
- **Pendientes visibles:**
  - **Fase5.4 completada — Migración de Engines a Domain Tracker:**
    - Domain RouletteTracker: métodos públicos `getStats()`, `getAdvancedStats()`, `static getWheelDistance()` añadidos.
    - DA, Chi, Orion, Sesgo97: `.settings` → `.getSettings()`.
    - Kelly: `tracker.spins` → `tracker.getSpins()`.
    - Bootstrap.js inyecta `domainTracker` a todos los engines.
    - main.js: 3 llamadas `kelly.analyze(tracker, ...)` → `domainTracker`.
    - Build: 78 módulos, 0 errores, 490ms.
    - **Pendiente:** MonteCarloValidator (crea su propio Legacy tracker).

## 3️⃣ Cómo podemos seguir avanzando
- **Próximos pasos inmediatos:**
  1. Abrir el navegador en `http://localhost:3000` y confirmar que la UI carga sin errores visuales.
  2. Probar el nuevo acordeón de Ajustes_vito: cambiar valores por módulo, guardar, recargar y verificar que persisten.
  3. Verificar que las tarjetas de atrasos en cada sección reflejan los umbrales correctos (límite, crítico, ventana de máximo histórico).
  4. Interactuar con los controles de simulación para detectar posibles excepciones o datos faltantes.
  5. Si aparecen errores, inspeccionarlos y corregir importaciones o lógica en los módulos JS.
- **Iteraciones posteriores:**
  - Añadir tests unitarios para los motores de lógica.
  - Implementar un tema oscuro avanzado y micro‑animaciones (usar CSS variables, `@keyframes`).
  - Documentar la arquitectura en un `README.md` con instrucciones de despliegue y uso.
  - Preparar un script de `build` y generar una versión estática para despliegue.
- **Mantenimiento continuo:**
  - Mantener actualizado `package.json` y ejecutar `npm audit fix` regularmente.
  - Ejecutar `./backup_orion.sh` antes de cambios y conservar solo los 3 respaldos más recientes.
  - Guardar este arnés actualizado en `arnes_orion.md` y referenciarlo en cada sesión de desarrollo.
  - Considerar `contexto_orion.md` como la segunda lectura obligatoria de la sesión.
- **Regla de confirmación**: antes de cualquier cambio destructivo, refactorización, escritura de archivos o acción irreversible, **pedir confirmación al usuario**. No ejecutar sin consentimiento explícito.

---
**Nota:** Cada vez que avances, actualiza este archivo con la información más reciente para que siempre tengas a mano respuestas claras a las tres preguntas clave.
